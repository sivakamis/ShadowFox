# Proof of Work (POW)

Add the following here:
- `linkedin_task1.png`, `linkedin_task2.png` – screenshots of your posts
- `github_repo.png` – screenshot of this repo home
- `video_thumbnail.png` – screenshot of your video
- `links.md` – paste URLs for LinkedIn post(s) and your video(s)
