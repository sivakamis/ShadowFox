import os
import numpy as np
import matplotlib.pyplot as plt

IM_DIR = os.path.join(os.path.dirname(__file__), "..", "images")
os.makedirs(IM_DIR, exist_ok=True)

# 1) Line
x = np.linspace(0, 10, 100)
y = np.sin(x)
plt.figure()
plt.plot(x, y, marker='o')
plt.title("Matplotlib – Line Plot")
plt.xlabel("x")
plt.ylabel("sin(x)")
plt.savefig(os.path.join(IM_DIR, "mpl_line.png"), dpi=150)
plt.close()

# 2) Bar
categories = ["A", "B", "C", "D"]
values = [5, 7, 3, 4]
plt.figure()
plt.bar(categories, values)
plt.title("Matplotlib – Bar Chart")
plt.xlabel("Category")
plt.ylabel("Value")
plt.savefig(os.path.join(IM_DIR, "mpl_bar.png"), dpi=150)
plt.close()

# 3) Histogram
data = np.random.randn(1000)
plt.figure()
plt.hist(data, bins=30, edgecolor='black')
plt.title("Matplotlib – Histogram")
plt.xlabel("Value")
plt.ylabel("Frequency")
plt.savefig(os.path.join(IM_DIR, "mpl_hist.png"), dpi=150)
plt.close()

# 4) Scatter
x = np.random.rand(50)
y = np.random.rand(50)
plt.figure()
plt.scatter(x, y)
plt.title("Matplotlib – Scatter Plot")
plt.xlabel("X")
plt.ylabel("Y")
plt.savefig(os.path.join(IM_DIR, "mpl_scatter.png"), dpi=150)
plt.close()

# 5) Pie
sizes = [25, 35, 15, 25]
labels = ["Q1", "Q2", "Q3", "Q4"]
plt.figure()
plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
plt.title("Matplotlib – Pie Chart")
plt.savefig(os.path.join(IM_DIR, "mpl_pie.png"), dpi=150)
plt.close()

# 6) Area (fill_between)
x = np.linspace(0, 10, 100)
y1 = np.sin(x) + 1
y2 = np.cos(x) + 1
plt.figure()
plt.fill_between(x, y1, alpha=0.5, label='sin(x)+1')
plt.fill_between(x, y2, alpha=0.5, label='cos(x)+1')
plt.legend()
plt.title("Matplotlib – Area Plot")
plt.xlabel("x")
plt.ylabel("y")
plt.savefig(os.path.join(IM_DIR, "mpl_area.png"), dpi=150)
plt.close()

print("Matplotlib figures saved to:", IM_DIR)
