import os
import seaborn as sns
import matplotlib.pyplot as plt

IM_DIR = os.path.join(os.path.dirname(__file__), "..", "images")
os.makedirs(IM_DIR, exist_ok=True)

tips = sns.load_dataset("tips")

# 1) Scatter
plt.figure()
sns.scatterplot(data=tips, x="total_bill", y="tip", hue="sex")
plt.title("Seaborn – Scatter Plot")
plt.savefig(os.path.join(IM_DIR, "sns_scatter.png"), dpi=150)
plt.close()

# 2) Line
plt.figure()
sns.lineplot(data=tips, x="size", y="tip", marker="o")
plt.title("Seaborn – Line Plot")
plt.savefig(os.path.join(IM_DIR, "sns_line.png"), dpi=150)
plt.close()

# 3) Bar
plt.figure()
sns.barplot(data=tips, x="day", y="total_bill")
plt.title("Seaborn – Bar Plot")
plt.savefig(os.path.join(IM_DIR, "sns_bar.png"), dpi=150)
plt.close()

# 4) Count
plt.figure()
sns.countplot(data=tips, x="day", hue="sex")
plt.title("Seaborn – Count Plot")
plt.savefig(os.path.join(IM_DIR, "sns_count.png"), dpi=150)
plt.close()

# 5) Box
plt.figure()
sns.boxplot(data=tips, x="day", y="total_bill")
plt.title("Seaborn – Box Plot")
plt.savefig(os.path.join(IM_DIR, "sns_box.png"), dpi=150)
plt.close()

# 6) KDE / Hist
plt.figure()
sns.kdeplot(data=tips, x="total_bill", fill=True)
plt.title("Seaborn – KDE Plot")
plt.savefig(os.path.join(IM_DIR, "sns_kde.png"), dpi=150)
plt.close()

# 7) Heatmap (correlation)
plt.figure()
corr = tips.corr(numeric_only=True)
sns.heatmap(corr, annot=True)
plt.title("Seaborn – Heatmap (Correlation)")
plt.savefig(os.path.join(IM_DIR, "sns_heatmap.png"), dpi=150)
plt.close()

print("Seaborn figures saved to:", IM_DIR)
