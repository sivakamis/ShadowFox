# Task 1 – Visualization Library Documentation (Matplotlib & Seaborn)

## What this folder contains
- `docs/Visualization_Guide.pdf` – Final PDF (your completed document).
- `code/` – Reproducible scripts for each chart type.
- `images/` – Saved PNGs of plots (for screenshots/POW).
- `notebooks/` *(optional)* – If you prefer Jupyter versions.

## How to reproduce
```bash
python code/matplotlib_examples.py
python code/seaborn_examples.py
```
The scripts will save example figures to `images/`.

## Checklist
- [ ] Final PDF saved in `docs/`
- [ ] All plots run without errors
- [ ] Screenshots added to `images/`
- [ ] Short video recorded and posted to LinkedIn (link saved in `proofs/links.md`)
