import os
import pandas as pd
from datetime import datetime, timedelta
import numpy as np

RAW_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
os.makedirs(RAW_DIR, exist_ok=True)

start = datetime(2024, 1, 1)
rows = []
cities = ["Chennai", "Coimbatore", "Madurai"]
np.random.seed(7)

for city in cities:
    dt = start
    for _ in range(30):
        rows.append({
            "city": city,
            "date": dt.strftime("%Y-%m-%d"),
            "PM2.5": max(5, np.random.normal(65, 20)),
            "PM10": max(10, np.random.normal(110, 30)),
            "NO2": max(5, np.random.normal(40, 10)),
            "O3": max(5, np.random.normal(50, 10))
        })
        dt += timedelta(days=1)

df = pd.DataFrame(rows)
out = os.path.join(RAW_DIR, "aqi_sample.csv")
df.to_csv(out, index=False)
print("Wrote", out)
