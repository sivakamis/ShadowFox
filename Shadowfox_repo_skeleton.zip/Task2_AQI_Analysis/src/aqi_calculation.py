import os
import pandas as pd
import numpy as np

RAW = os.path.join(os.path.dirname(__file__), "..", "data", "raw", "aqi_sample.csv")
PROCESSED_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "processed")
os.makedirs(PROCESSED_DIR, exist_ok=True)

# Breakpoints (US EPA-like, simplified) for PM2.5 (µg/m3)
PM25_BP = [
    (0.0, 12.0, 0, 50),
    (12.1, 35.4, 51, 100),
    (35.5, 55.4, 101, 150),
    (55.5, 150.4, 151, 200),
    (150.5, 250.4, 201, 300),
    (250.5, 350.4, 301, 400),
    (350.5, 500.4, 401, 500),
]

# Breakpoints (US EPA-like, simplified) for PM10 (µg/m3)
PM10_BP = [
    (0, 54, 0, 50),
    (55, 154, 51, 100),
    (155, 254, 101, 150),
    (255, 354, 151, 200),
    (355, 424, 201, 300),
    (425, 504, 301, 400),
    (505, 604, 401, 500),
]

def calc_subindex(Cp, breakpoints):
    for Clow, Chigh, Ilow, Ihigh in breakpoints:
        if Clow <= Cp <= Chigh:
            # Linear interpolation: I = (Ih-Il)/(Ch-Cl)*(Cp-Cl)+Il
            return (Ihigh - Ilow) / (Chigh - Clow) * (Cp - Clow) + Ilow
    return np.nan

def compute_indices(df):
    df = df.copy()
    df["AQI_PM25"] = df["PM2.5"].apply(lambda x: calc_subindex(x, PM25_BP))
    df["AQI_PM10"] = df["PM10"].apply(lambda x: calc_subindex(x, PM10_BP))
    # Overall AQI as max of available sub-indices (simplified)
    df["AQI"] = df[["AQI_PM25", "AQI_PM10"]].max(axis=1)
    return df

df = pd.read_csv(RAW)
df_out = compute_indices(df)
out_path = os.path.join(PROCESSED_DIR, "aqi_with_index.csv")
df_out.to_csv(out_path, index=False)
print("Wrote", out_path)
