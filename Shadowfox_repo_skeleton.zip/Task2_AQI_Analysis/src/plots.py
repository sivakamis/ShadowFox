import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

PROCESSED = os.path.join(os.path.dirname(__file__), "..", "data", "processed", "aqi_with_index.csv")
IM_DIR = os.path.join(os.path.dirname(__file__), "..", "images")
os.makedirs(IM_DIR, exist_ok=True)

df = pd.read_csv(PROCESSED, parse_dates=["date"])

# 1) Trend by city
plt.figure()
sns.lineplot(data=df, x="date", y="AQI", hue="city", marker="o")
plt.title("AQI Trends by City")
plt.xlabel("Date")
plt.ylabel("AQI")
plt.tight_layout()
plt.savefig(os.path.join(IM_DIR, "aqi_trend_by_city.png"), dpi=150)
plt.close()

# 2) Average AQI by city (bar)
plt.figure()
avg = df.groupby("city")["AQI"].mean().reset_index()
sns.barplot(data=avg, x="city", y="AQI")
plt.title("Average AQI by City")
plt.tight_layout()
plt.savefig(os.path.join(IM_DIR, "avg_aqi_by_city.png"), dpi=150)
plt.close()

# 3) Heatmap (day vs city)
pivot = df.pivot_table(index="city", columns=df["date"].dt.strftime("%Y-%m-%d"), values="AQI")
plt.figure(figsize=(10, 4))
sns.heatmap(pivot, annot=False)
plt.title("AQI Heatmap (City x Date)")
plt.tight_layout()
plt.savefig(os.path.join(IM_DIR, "aqi_heatmap.png"), dpi=150)
plt.close()

print("Saved charts to:", IM_DIR)
