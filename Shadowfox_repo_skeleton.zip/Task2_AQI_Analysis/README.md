# Task 2 – Air Quality Index (AQI) Analysis

## What this folder contains
- `data/` – raw CSVs and cleaned/processed data
- `src/` – scripts to generate demo data, compute AQI sub-indices, and plot
- `images/` – exported figures
- `reports/` – your final PDF report goes here

## How to run (demo)
```bash
python src/make_demo_data.py        # creates data/raw/aqi_sample.csv
python src/aqi_calculation.py       # computes AQI & saves data/processed/aqi_with_index.csv
python src/plots.py                 # generates charts to images/
```
Then write your final **AQI_Analysis.pdf** and save it in `reports/`.

## Checklist
- [ ] Raw data placed in `data/raw/`
- [ ] Cleaned CSV saved to `data/processed/`
- [ ] Plots exported to `images/`
- [ ] Final report saved to `reports/`
- [ ] Video recorded + LinkedIn post made (link saved in `proofs/links.md`)
