# ShadowFox – Data Science Internship

This repository contains all internship tasks for the **ShadowFox Data Science Internship**, including documentation, code, datasets, visualizations, and proof-of-work.

## Repository Structure
```
Shadowfox/
├── Task1_Visualization_Docs/
│   ├── code/
│   ├── docs/
│   ├── images/
│   ├── notebooks/  (optional)
│   └── README.md
├── Task2_AQI_Analysis/
│   ├── data/
│   │   ├── raw/
│   │   └── processed/
│   ├── src/
│   ├── images/
│   ├── reports/
│   └── README.md
├── proofs/  (screenshots + links)
├── requirements.txt
├── .gitignore
└── LICENSE
```

## Quick Start
1. Create a Python environment and install requirements:
   ```bash
   pip install -r requirements.txt
   ```

2. (Task 1) Run example scripts to generate plots:
   ```bash
   python Task1_Visualization_Docs/code/matplotlib_examples.py
   python Task1_Visualization_Docs/code/seaborn_examples.py
   ```
   Screenshots/PNGs will be saved to `Task1_Visualization_Docs/images/`.

3. (Task 2) Generate demo AQI data and sample charts:
   ```bash
   python Task2_AQI_Analysis/src/make_demo_data.py
   python Task2_AQI_Analysis/src/plots.py
   ```
   Outputs will be saved in `Task2_AQI_Analysis/data/processed/` and `Task2_AQI_Analysis/images/`.

## Proof of Work (POW)
- Put screenshots and links in `proofs/`:
  - `linkedin_task1.png`, `linkedin_task2.png`
  - `github_repo.png`, `video_thumbnail.png`
  - `links.md` (LinkedIn post URLs + YouTube/Drive video URLs)
